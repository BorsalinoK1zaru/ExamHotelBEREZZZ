package com.example.demo.model;

public enum Capacity {
    SINGLE,
    DOUBLE,
    FOURSEATER
}
